---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

<!-- The author may be close the report if issue template is ignored. -->

#### Checkhealth

Put result of `:checkhealth compe`.

```
```


#### Describe the bug


#### To Reproduce

Steps to reproduce the behavior with the [minimal config](https://github.com/hrsh7th/nvim-compe/blob/master/misc/minimal.vim):

1. ...
2. ...
3. ...


#### Actual behavior


#### Expected behavior


#### Screenshots (optional)


#### Additional context (optional)


