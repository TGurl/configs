// File with 4-spaces indentation
function foobar() {
    foo = bar
    while (true) {
        fizfuz()
        fizfuz()
        fizfuz()
        fizfuz()
    }
}
